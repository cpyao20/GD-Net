import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from models.utils.layers import unetConv2, unetUp, unetConv2_dilation, unetUp_m
from models.utils.init_weights import init_weights


class GDNet(nn.Module):

    def __init__(self, in_channels=1, num_classes=3, feature_scale=2, is_deconv=True, is_batchnorm=True):
        super(GDNet, self).__init__()
        self.is_deconv = is_deconv
        self.in_channels = in_channels
        self.is_batchnorm = is_batchnorm
        self.feature_scale = feature_scale

        filters = [64, 128, 256, 512, 1024]
        filters = [int(x / self.feature_scale) for x in filters]

        # downsampling
        self.conv1 = unetConv2(self.in_channels, filters[0], self.is_batchnorm)
        self.maxpool1 = nn.MaxPool2d(kernel_size=2)

        self.conv2 = unetConv2(filters[0], filters[1], self.is_batchnorm)
        self.maxpool2 = nn.MaxPool2d(kernel_size=2)

        self.conv3 = unetConv2(filters[1], filters[2], self.is_batchnorm)
        self.maxpool3 = nn.MaxPool2d(kernel_size=2)

        self.conv4 = unetConv2(filters[2], filters[3], self.is_batchnorm)
        self.maxpool4 = nn.MaxPool2d(kernel_size=2)

        self.center = unetConv2(filters[3], filters[4], self.is_batchnorm)
        self.sam = PAM_Module(filters[4])

        # upsampling
        self.up_concat_1_4 = unetUp(filters[4], filters[3], self.is_deconv)
        self.up_concat_1_3 = unetUp(filters[3], filters[2], self.is_deconv)
        self.up_concat_1_2 = unetUp(filters[2], filters[1], self.is_deconv)
        self.up_concat_1_1 = unetUp(filters[1], filters[0], self.is_deconv)

        # upsampling_two
        self.up_concat_2_4 = unetUp(filters[4], filters[3], self.is_deconv)
        self.up_concat_2_3 = unetUp(filters[3], filters[2], self.is_deconv)
        self.up_concat_2_2 = unetUp(filters[2], filters[1], self.is_deconv)
        self.up_concat_2_1 = unetUp(filters[1], filters[0], self.is_deconv)

        # final conv (without any concat)
        self.final_1 = nn.Conv2d(filters[0], 1, 1)
        self.final_2 = nn.Conv2d(filters[0], num_classes, 1)

        # initialise weights
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init_weights(m, init_type='kaiming')
            elif isinstance(m, nn.BatchNorm2d):
                init_weights(m, init_type='kaiming')

    def forward(self, inputs):
        conv1 = self.conv1(inputs)  # 16*512*1024
        maxpool1 = self.maxpool1(conv1)  # 16*256*512

        conv2 = self.conv2(maxpool1)  # 32*256*512
        maxpool2 = self.maxpool2(conv2)  # 32*128*256

        conv3 = self.conv3(maxpool2)  # 64*128*256
        maxpool3 = self.maxpool3(conv3)  # 64*64*128

        conv4 = self.conv4(maxpool3)  # 128*64*128
        maxpool4 = self.maxpool4(conv4)  # 128*32*64

        center = self.center(maxpool4)  # 256*32*64
        sam = self.sam(center)

        up_1_4 = self.up_concat_1_4(center, conv4)  # 128*64*128
        up_1_3 = self.up_concat_1_3(up_1_4, conv3)  # 64*128*256
        up_1_2 = self.up_concat_1_2(up_1_3, conv2)  # 32*256*512
        up_1_1 = self.up_concat_1_1(up_1_2, conv1)  # 16*512*1024

        up_2_4 = self.up_concat_2_4(sam, conv4+up_1_4)  # 128*64*128
        up_2_3 = self.up_concat_2_3(up_2_4, conv3+up_1_3)  # 64*128*256
        up_2_2 = self.up_concat_2_2(up_2_3, conv2+up_1_2)  # 32*256*512
        up_2_1 = self.up_concat_2_1(up_2_2, conv1+up_1_1)  # 16*512*1024

        final_1 = self.final_1(up_1_1)
        final_2 = self.final_2(up_2_1)

        return F.log_softmax(final_2, dim=1), F.sigmoid(final_1)



class PAM_Module(nn.Module):
    """ Position attention module"""
    #Ref from SAGAN
    def __init__(self, in_dim):
        super(PAM_Module, self).__init__()
        self.chanel_in = in_dim

        self.query_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim//8, kernel_size=1)
        self.key_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim//8, kernel_size=1)
        self.value_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim, kernel_size=1)

        self.extra_conv = nn.Conv2d(in_channels=in_dim, out_channels=in_dim, kernel_size=1)

        self.fuse = nn.Conv2d(in_channels=(in_dim*2), out_channels=in_dim, kernel_size=3, padding=1)

        self.gamma = nn.Parameter(torch.zeros(1))

        self.softmax = nn.Softmax(dim=-1)
    def forward(self, x):
        """
            inputs :
                x : input feature maps( B X C X H X W)
            returns :
                out : attention value + input feature
                attention: B X (HxW) X (HxW)
        """
        m_batchsize, C, height, width = x.size()

        proj_query = self.query_conv(x).view(m_batchsize, -1, width*height).permute(0, 2, 1)
        proj_key = self.key_conv(x).view(m_batchsize, -1, width*height)
        energy = torch.bmm(proj_query, proj_key)

        attention = self.softmax(energy)
        proj_value = self.value_conv(x).view(m_batchsize, -1, width*height)
        out_1 = torch.bmm(proj_value, attention.permute(0, 2, 1))

        proj_extra = self.extra_conv(x).view(m_batchsize, -1, width*height)
        out_2 = torch.bmm(proj_extra, (1-attention).permute(0, 2, 1))

        out = torch.cat([out_1, out_2], dim=1)
        out = out.view(m_batchsize, C*2, height, width)
        out = self.fuse(out)


        out = self.gamma*out + x
        return out

# ------------------------------------------------------------------------------------------------------

if __name__ == '__main__':
    os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    net = GDNet(in_channels=1, num_classes=4, is_deconv=True).cuda()
    x = torch.rand((4, 1, 256, 128)).cuda()
    forward = net.forward(x)
    # print(forward[0].shape)
    # print(forward[1].shape)
    # print(type(forward))

#    net = resnet34_unet(in_channel=1,out_channel=4,pretrain=False).cuda()
#    torchsummary.summary(net, (1, 512, 512))