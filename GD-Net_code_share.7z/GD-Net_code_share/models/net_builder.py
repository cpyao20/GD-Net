
from models.nets.GDNet import GDNet

def net_builder(name,num_classes=3,pretrained=False):
    if name == 'DualDeco_UNet_V5_NewModule_loss46':
        net = GDNet(num_classes=num_classes)


    else:
        raise NameError("Unknow Model Name!")
    return net
