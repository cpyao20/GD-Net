##### System library #####
import os
import numpy as np
from  PIL import Image
from  utils.config import DefaultConfig
import glob


if __name__ == '__main__':
    args = DefaultConfig()
    dataset_path = os.path.join(args.data, args.dataset)
    image_path = dataset_path + '\\train' + '\\img'
    mask_path = dataset_path + '\\train' + '\\mask'
    # image_path = dataset_path + '\\valid' + '\\img'
    # mask_path = dataset_path + '\\valid' + '\\mask'
    fold = sorted(os.listdir(image_path))
    img_list = []

    fold_r = list(fold)  # remove testdata
    for item in fold_r:
        # for fold_cube in sorted(os.listdir(os.path.join(image_path,item)),key=lambda x: int(x[-3:])):
        for fold_cube in sorted(os.listdir(os.path.join(image_path, item)), key=lambda x: x[-3:]):
            cube_path = os.path.join(os.path.join(image_path, item), fold_cube)
            # img_list+=sorted(glob.glob(cube_path+'/*.png'),key=lambda x: (int(x.split('/')[-1][-3:]),int(x.split('/')[-1].split('.')[0][-3:])))
            img_list += sorted(glob.glob(cube_path + '/*.png'), key=lambda x: (
            int(x.split('\\')[-2][-4:]), int(x.split('\\')[-1].split('.')[0][-3:])))  # two keys sorted 文件夹名和文件名
            label_list = [x.replace('img', 'mask') for x in img_list]

    for index in range(len(label_list)):
        label_path = label_list[index]
        label = Image.open(label_path)
        label = np.array(label).astype(np.uint8)
        label = label.transpose(2, 0, 1)
        label_sd = np.zeros([512, 256])
        label_sd[label[0] == 255] = 1
        label_sd[label[1] == 255] = 2
        label_sd[label[2] == 255] = 3
        label = label_sd
        label = Image.fromarray(label)
        label = label.convert("L")
        label.save(label_path.replace('mask', 'mask2'))