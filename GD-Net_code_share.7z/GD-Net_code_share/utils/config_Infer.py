# -*- coding: utf-8 -*-
class DefaultConfig(object):
    
    # 数据集与日志
    net_work = 'ce_net'
    data = './dataset'  # 数据存放的根目录
    dataset = 'oct'  # 数据库名字(需修改成自己的数据名字)
    log_dirs = './Log'  # 存放tensorboard log的文件夹()
    save_model_path = './Results/{}'.format(net_work)
    save_model_path_trained = './model_saved/{}'.format(net_work)

    # 网络训练设置
    best_model = 'OCT_WSegNet_tmp.pkl'
    mode = 'train'
    num_epochs = 100
    batch_size = 2
    loss_type = 'mix_dice' 
    multitask = True
    validation_step = 1
    in_channels = 1
    num_classes = 3  # 分割类别数，二类分割设置为1，多类分割设置成 类别数+加背景
    crop_height = 1024  # 输入图像裁切
    crop_width = 1024

    # 优化器设置
    lr = 0.0005
    lr_mode = 'poly'
    momentum = 0.9
    weight_decay = 1e-4  # L2正则化系数
    
    # 预训练模型
    pretrained = False
    pretrained_model_path = None

    # 断点恢复（latest checkpoint路径）
    resume_model_path = None
    continu = False
    # 模型保存设置
    save_every_checkpoint = False
    
    # GPU使用
    cuda = '6'
    num_workers = 4
    use_gpu = True
    
    # 网络预测
    trained_model_path = ''  # test的时候模型文件的选择（当mode='test'的时候用）
    predict_fold = 'predict_mask'
    

    
    