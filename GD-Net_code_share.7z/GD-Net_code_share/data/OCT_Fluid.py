# -*- coding: utf-8 -*-
import torch
import glob
import os

from torchvision import transforms
from PIL import Image
import numpy as np
from imgaug import augmenters as iaa
import imgaug as ia
#from utils.utils import one_hot_it
import random
# from utils.config import DefaultConfig


class OCT_Fluid(torch.utils.data.Dataset):

    def __init__(self, dataset_path, scale, k_fold_test=1, mode='train'):
        super().__init__()
        self.mode = mode
        if mode != 'test':
            self.img_path=dataset_path+'/train'+'/img'
            self.mask_path=dataset_path+'/train'+'/mask'
        else:
            self.img_path=dataset_path+'/valid'+'/img'
            self.mask_path=dataset_path+'/valid'+'/mask'
        self.image_lists,self.label_lists = self.read_list(self.img_path,k_fold_test=k_fold_test)
        # data augmentation
        self.aug =iaa.Sequential([
             iaa.Fliplr(0.1),
             # iaa.SomeOf((1,4),[
             #     iaa.Affine(
             #         scale={"x": (0.9, 1.1), "y": (0.9, 1.1)},                 #尺度缩放
             #         translate_percent={"x": (-0.1, 0.1), "y": (-0.1, 0.1)},   #平移
             #         rotate=(-10, 10)),                                        #旋转
             #     iaa.OneOf([
             #         iaa.GaussianBlur((0, 1.0)),
             #         iaa.AverageBlur(k=(0, 3)),
             #         iaa.MedianBlur(k=(1, 3))]),
             #     iaa.AdditiveGaussianNoise(scale=(0.0,0.06*255)),              #高斯噪声
             #     iaa.contrast.LinearContrast((0.9, 1.1))
             # ],random_order=True)
        ])   #对比度
        # resize
        self.resize_label = transforms.Resize(scale, Image.NEAREST)
        self.resize_img = transforms.Resize(scale, Image.BILINEAR)
        self.to_gray = transforms.Grayscale()
        # normalization
        self.to_tensor = transforms.ToTensor()                                 #将numpy的ndarray或PIL.Image读的图片转换成形状为(C,H, W)的Tensor格式，且/255归一化到[0,1.0]之间
       
    def __getitem__(self, index):
        # load image
        img = Image.open(self.image_lists[index])
        img = self.resize_img(img)
        img = np.array(img).astype(np.uint8)
        labels = self.label_lists[index]


        #load label
        if self.mode !='test':
            label = Image.open(self.label_lists[index])
            label = self.resize_label(label)
            label = np.array(label).astype(np.uint8)
            label[label == 0] = 0
            label[label == 127] = 1
            label[label == 255] = 2                                                # H*W 索引为0123

            label_single = label.copy()
            label_single[label_single>0] = 1


            # augment image and label
            # if self.mode == 'train':
            #     seq_det = self.aug.to_deterministic()                          #得到一个确定的增强函数
            #     # 将图片转换为SegmentationMapOnImage类型
            #     segmap = ia.SegmentationMapsOnImage(label, shape=label.shape, nb_classes=3)
            #
            #     # 将方法应用在原图像上
            #     img = seq_det.augment_image(img)
            #
            #     # 将方法应用在分割标签上，并且转换成np类型
            #     label = seq_det.augment_segmentation_maps([segmap])[0]
            #     label = label.get_arr().astype(np.uint8)
            #
            #     label_single = seq_det.augment_segmentation_maps([segmap])[0]
            #     label_single = label_single.get_arr().astype(np.uint8)
            #
            #
            #     #[segmap]中可以填入多个mask，seq_det.augment_segmentation_maps([segmap])结果为列表
            #     #SegmentationMapOnImage用get_arr_int()将图片转为array
            label = label.reshape(1, label.shape[0], label.shape[1])
            label_single = label_single.reshape(1, label_single.shape[0], label_single.shape[1])
            label_img=torch.from_numpy(label.copy()).float()
            label_single_img=torch.from_numpy(label_single.copy()).float()

            if self.mode=='val' or self.mode=='test':
                assert len(os.listdir(os.path.dirname(self.image_lists[index]))) == len(os.listdir(os.path.dirname(labels)))
                img_num=len(os.listdir(os.path.dirname(labels)))
                labels=(label_img,label_single_img,img_num)                                     #val模式下labels返回一个元祖，[0]为tensor标签索引值h*w，[1]为cube中包含slice张数int值
            else:
                labels=(label_img,label_single_img)                                              #train模式下labels返回tensor标签索引值
            
        if len(img.shape) > 2:
            img = (img.transpose(2,0,1)-127.5)/127.5
        else:
            img = np.reshape(img,img.shape+(1,))
            img = (img.transpose(2,0,1)-127.5)/127.5
        img = torch.from_numpy(img.copy()).float()
        #test模式下labels返回label的路径列表
        return img, labels
 
    
    def __len__(self):
        return len(self.image_lists)
    
    
    def read_list(self,image_path,k_fold_test=1):
        fold=sorted(os.listdir(image_path))
        img_list=[]

        if self.mode=='train':
            fold_r=list(fold)
            fold_r.remove('f'+str(k_fold_test))                                # remove testdata
            print("train_folds_are =============== {}".format(fold_r))
            for item in fold_r:

                cube_path = os.path.join(os.path.join(image_path,item))
                # two keys sorted 文件夹名和文件名
                img_list += sorted(glob.glob(cube_path+'/*.png'), key=lambda x: int(x.split('/')[-1].split('.')[0][-3:]))
                label_list = [x.replace('img','mask') for x in img_list]

        elif self.mode=='val':
            fold_s = fold[k_fold_test - 1]
            print("val_fold_is =============== {}".format(fold_s))
            cube_path = os.path.join(os.path.join(image_path,fold_s)).replace('train','valid')
            img_list += sorted(glob.glob(cube_path + '/*.png'), key=lambda x: int(x.split('/')[-1].split('.')[0]))
            label_list = [x.replace('img','mask') for x in img_list]

        elif self.mode=='test':
            fold_s = fold[k_fold_test - 1]
            cube_path = os.path.join(os.path.join(image_path,fold_s)).replace('train','valid')
            img_list += sorted(glob.glob(cube_path + '/*.png'), key=lambda x: int(x.split('/')[-1].split('.')[0]))
            label_list = [x.replace('img','mask') for x in img_list]
        
        # if self.mode=='train':
        #     fold_r=list(fold)
        #     fold_r.remove('f'+str(k_fold_test))                                # remove testdata
        #     for item in fold_r:
        #         for fold_cube in sorted(os.listdir(os.path.join(image_path, item)), key=lambda x: x[-3:]):
        #             cube_path = os.path.join(os.path.join(image_path,item),fold_cube)
        #             img_list+=sorted(glob.glob(cube_path+'/*.png'),key=lambda x: (int(x.split('/')[-2][-3:]),int(x.split('/')[-1].split('.')[0][-3:])))#two keys sorted 文件夹名和文件名
        #             label_list=[x.replace('img','mask') for x in img_list]
        #
        # elif self.mode=='val':
        #     fold_s = fold[k_fold_test - 1]
        #     for fold_cube in sorted(os.listdir(os.path.join(image_path,fold_s)),key=lambda x: int(x[-3:])):
        #         cube_path = os.path.join(os.path.join(image_path,fold_s),fold_cube).replace('train','valid')
        #         img_list += sorted(glob.glob(cube_path + '/*.png'), key=lambda x: (int(x.split('/')[-2]), int(x.split('/')[-1].split('.')[0])))
        #         label_list=[x.replace('img','mask') for x in img_list]
        #
        # elif self.mode=='test':
        #     fold_s = fold[k_fold_test - 1]
        #     for fold_cube in sorted(os.listdir(os.path.join(image_path,fold_s)),key=lambda x: int(x[-3:])):
        #         cube_path = os.path.join(os.path.join(image_path,fold_s),fold_cube).replace('train','valid')
        #         img_list += sorted(glob.glob(cube_path + '/*.png'), key=lambda x: (int(x.split('/')[-2]), int(x.split('/')[-1].split('.')[0])))
        #         label_list=[x.replace('img','mask') for x in img_list]

        assert len(img_list) == len(label_list)
        print ('Total {} image is:{}'.format(self.mode,len(img_list)))
        
        return img_list,label_list
    
    
if __name__ == '__main__':
    from torch.utils.data import DataLoader
    data = OCT_Fluid('./dataset/caizhao',(512,256),mode='val')
    dataloader_train = DataLoader(
        data,
        batch_size=2,
        shuffle=True,
        num_workers=0,
        pin_memory=True,
        drop_last=True 
    )
    for i, (img, label) in enumerate(dataloader_train):
        #label[0] = label[0].transpose(0, 2, 3, 1)
        label_show=Image.fromarray(label[0][0].data.numpy().squeeze().astype(np.uint8))
        slice_num=label[1][0].long().item()
        #slice_num = 1
        print(slice_num)
        img=img*255.0
        label[0][label[0] == 0] = 255
        label[0][label[0] == 1] = 200
        label[0][label[0] == 2] = 150
        label[0][label[0] == 3] = 100
        label[0][label[0] == 4] = 50
        label[0][label[0] == 5] = 0
        img = img.data.numpy().squeeze()
        img = img.transpose(0, 2, 3, 1)
        img_show=Image.fromarray(img[0].astype(np.uint8))
        
        if i>-1:
            break    