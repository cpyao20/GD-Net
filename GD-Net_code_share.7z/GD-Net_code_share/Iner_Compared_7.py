# -*- coding: utf-8 -*-
##### System library #####
import os
import tqdm
import torch
from torch.utils.data import DataLoader
from data.OCT_Fluid_label2label import OCT_Fluid
import utils.utils as u
from models.net_builder import net_builder
from utils.config_Infer import DefaultConfig
import glob
import cv2
import numpy as np
torch.set_num_threads(1)

def val(args, model, dataloader,k_fold):
    print('\n')
    print('Start Validation!')
    with torch.no_grad():  # 适用于推断阶段，不需要反向传播
        model.eval()  # 测试模式，自动把BN和DropOut固定住，用训练好的值
        tbar = tqdm.tqdm(dataloader, desc='\r')  # 添加一个进度提示信息，只需要封装任意的迭代器 tqdm(iterator)，desc进度条前缀

        total_Dice = []  # total_Dice中包含2个类别的dice列表
        total_Dice1 = []
        total_Dice2 = []
        total_Dice.append(total_Dice1)
        total_Dice.append(total_Dice2)

        total_IoU = []  # total_Dice中包含2个类别的dice列表
        total_IoU1 = []
        total_IoU2 = []
        total_IoU.append(total_IoU1)
        total_IoU.append(total_IoU2)

        total_Acc = []  # total_Dice中包含2个类别的dice列表
        total_Acc1 = []
        total_Acc2 = []
        total_Acc.append(total_Acc1)
        total_Acc.append(total_Acc2)


        total_Se = []  # total_Dice中包含2个类别的dice列表
        total_Se1 = []
        total_Se2 = []
        total_Se.append(total_Se1)
        total_Se.append(total_Se2)


        total_Pre = []  # total_Dice中包含2个类别的dice列表
        total_Pre1 = []
        total_Pre2 = []
        total_Pre.append(total_Pre1)
        total_Pre.append(total_Pre2)




        cur_predict_cube = []
        cur_label_cube = []
        counter = 0
        end_flag = False

        if not os.path.exists(os.path.join(args.save_model_path, str(k_fold), "Ori")):
            os.makedirs(os.path.join(args.save_model_path, str(k_fold), "Ori"))
            os.makedirs(os.path.join(args.save_model_path, str(k_fold), "Mask"))
            os.makedirs(os.path.join(args.save_model_path, str(k_fold), "Preds"))

        for idx_val, (data, labels) in enumerate(tbar):  # i=300/batch_size=3
            # tbar.update()
            if torch.cuda.is_available() and args.use_gpu:
                data = data.cuda()
                label = labels[0].cuda()  # val模式下labels返回一个元祖，[0]为tensor标签索引值nhw，[1]为cube中包含slice张数int值15
            slice_num = args.batch_size  # slice_num=15 int型  一个元素张量可以用item得到元素值labels[1]=tensor([15])，labels[1][0]=tensor(15)

            # get RGB predict image

            predicts = model(data)
            predict = torch.argmax(torch.exp(predicts), dim=1)  # predicts预测结果nchw,寻找通道维度上的最大值predict变为nhw
            batch_size = predict.size(0)

            for idx_d in range(batch_size):
                data_arr = ((data[idx_d].squeeze(0).cpu().numpy() + 1) / 2) * 255
                data_arr = np.array(data_arr, dtype=np.uint8)
                mask_arr = label[idx_d].cpu().squeeze(0).numpy() * (255 // args.num_classes)
                mask_arr = np.array(mask_arr, dtype=np.uint8)

                predict_arr = predict[idx_d].cpu().numpy() * (255 // args.num_classes)
                predict_arr = np.array(predict_arr, dtype=np.uint8)

                cv2.imwrite(os.path.join(args.save_model_path, str(k_fold), "Ori/{}_{}.png".format(idx_val, idx_d)),
                            data_arr)
                cv2.imwrite(os.path.join(args.save_model_path, str(k_fold), "Mask/{}_{}.png".format(idx_val, idx_d)),
                            mask_arr)
                cv2.imwrite(os.path.join(args.save_model_path, str(k_fold), "Preds/{}_{}.png".format(idx_val, idx_d)),
                            predict_arr)









            counter += batch_size
            if counter <= slice_num:  # cube拼接
                cur_predict_cube.append(predict)
                cur_label_cube.append(label)
                if counter == slice_num:  # slice_num整除batch_size
                    end_flag = True
                    counter = 0  # counter清0，开始下一个cube计数
            if end_flag:  # 拼接完成，end_flag为True
                end_flag = False
                label_cube = torch.cat(cur_label_cube, dim=0).squeeze(1)
                predict_cube = torch.cat(cur_predict_cube, dim=0)  # 在0维拼接，列表转为slice_num*h*w的tensor

                cur_predict_cube = []  # 当前处理的cube列表清空
                cur_label_cube = []

                assert len(args.cuda.split(',')) * predict_cube.size()[0] == slice_num
                # Dice, True_label, IoU, acc, SE, Pre
                dice_list, true_label, iou_list, Acc_list, SE_list, Pre_list = u.eval_multi_seg_3D_infer(predict_cube, label_cube,
                                                            args.num_classes)  # 返回Dice列表, True_label列表中包含2个类别的像素数量，acc为标量值



                for class_id in range(args.num_classes - 1):  # true_label[0]  [1]  [2]分别对应标签1 2 3
                    if true_label[class_id] != 0:
                        total_Dice[class_id].append(dice_list[class_id])  # 如果该类别存在，total_Dice中对应的类别子列表加入该cube的该类计算结果值
                        total_IoU[class_id].append(iou_list[class_id])  # 如果该类别存在，total_Dice中对应的类别子列表加入该cube的该类计算结果值
                        total_Acc[class_id].append(Acc_list[class_id])  # 如果该类别存在，total_Dice中对应的类别子列表加入该cube的该类计算结果值
                        total_Se[class_id].append(SE_list[class_id])  # 如果该类别存在，total_Dice中对应的类别子列表加入该cube的该类计算结果值
                        total_Pre[class_id].append(Pre_list[class_id])  # 如果该类别存在，total_Dice中对应的类别子列表加入该cube的该类计算结果值


                len0 = len(total_Dice[0]) if len(total_Dice[0]) != 0 else 1
                len1 = len(total_Dice[1]) if len(total_Dice[1]) != 0 else 1
                dice1 = sum(total_Dice[0]) / len0
                dice2 = sum(total_Dice[1]) / len1
                mean_dice = (dice1 + dice2 ) / 2.0


                IoU1 = sum(total_IoU[0]) / len0
                IoU2 = sum(total_IoU[1]) / len1
                mean_IoU = (IoU1 + IoU2 ) / 2.0


                Acc1 = sum(total_Acc[0]) / len0
                Acc2 = sum(total_Acc[1]) / len1
                mean_Acc = (Acc1 + Acc2 ) / 2.0

                Se1 = sum(total_Se[0]) / len0
                Se2 = sum(total_Se[1]) / len1
                mean_Se = (Se1 + Se2 ) / 2.0
                
                Pre1 = sum(total_Pre[0]) / len0
                Pre2 = sum(total_Pre[1]) / len1
                mean_Pre = (Pre1 + Pre2 ) / 2.0


                tbar.set_description(
                    'Mean_D: %6f, Dice1: %.6f, Dice2: %.6f, mean_Acc: %.6f' % (
                    mean_dice, dice1, dice2, mean_Acc))
            print('counter ================ {}'.format(counter))


        print('Mean_Dice:', mean_dice)
        print('Dice1:', dice1)
        print('Dice2:', dice2)


        with open('{}/fold_{}_dice.txt'.format(args.save_model_path,k_fold), 'w') as f:
            f.write('Mean_Dice:' + " " + str(round(mean_dice, 6)) + ',')
            f.write('Mean_IoU:' + " " + str(round(mean_IoU, 6)) + ',')
            f.write('Mean_Acc:' + " " + str(round(mean_Acc, 6)) + ',')
            f.write('Mean_Se:' + " " + str(round(mean_Se, 6)) + ',')
            f.write('Mean_Pre:' + " " + str(round(mean_Pre, 6)) + ',')
            f.write('\n')

            f.write('Dice: 1:' + " " + str(round(dice1, 6)) + ',')
            f.write('IoU: 1:' + " " + str(round(IoU1, 6)) + ',')
            f.write('Acc: 1:' + " " + str(round(Acc1, 6)) + ',')
            f.write('Se: 1:' + " " + str(round(Se1, 6)) + ',')
            f.write('Pre: 1:' + " " + str(round(Pre1, 6)) + ',')
            f.write('\n')
            f.write('Dice: 2:' + " " + str(round(dice2, 6)) + ',')
            f.write('IoU: 2:' + " " + str(round(IoU2, 6)) + ',')
            f.write('Acc: 2:' + " " + str(round(Acc2, 6)) + ',')
            f.write('Se: 2:' + " " + str(round(Se2, 6)) + ',')
            f.write('Pre: 2:' + " " + str(round(Pre2, 6)) + ',')
            f.write('\n')
            f.write('\n')



        val_single(args, model, dataloader, k_fold)








def val_single(args, model, dataloader,k_fold):
    print('\n')
    print('Start Validation Single!')
    if not os.path.exists(os.path.join(args.save_model_path,str(k_fold),"Mask_Single")):
        os.makedirs(os.path.join(args.save_model_path,str(k_fold),"Mask_Single"))
        os.makedirs(os.path.join(args.save_model_path,str(k_fold),"Preds_Single"))

    with torch.no_grad():  # 适用于推断阶段，不需要反向传播
        model.eval()  # 测试模式，自动把BN和DropOut固定住，用训练好的值
        tbar = tqdm.tqdm(dataloader, desc='\r')  # 添加一个进度提示信息，只需要封装任意的迭代器 tqdm(iterator)，desc进度条前缀

        total_Dice0 = [[]]   # total_Dice中包含2个类别的dice列表
        total_PC=[]
        total_SE=[]
        total_Pre=[]
        total_JS=[]
        # total_F1=[[]]
        total_PCC=[]
        total_Acc = []

        cur_predict_cube = []
        cur_label_cube = []
        counter = 0
        end_flag = False

        for idx_val, (data, labels) in enumerate(tbar):  # i=300/batch_size=3
            # tbar.update()
            if torch.cuda.is_available() and args.use_gpu:
                data = data.cuda()
                label = labels[1].cuda()  # val模式下labels返回一个元祖，[0]为tensor,bnhw，[1]为cube中包含slice张数int值20
            slice_num =args.batch_size

            # get RGB predict image

            predict = model(data)
            predict = torch.argmax(torch.exp(predict),keepdim=True, dim=1)  # predicts预测结果nchw,寻找通道维度上的最大值predict变为nhw
            predict[predict>0] = 1

            batch_size = predict.size()[0]  # 即n
            for idx_d in range(batch_size):

                mask_arr = label[idx_d].squeeze(0).cpu().numpy()*255
                mask_arr = np.array(mask_arr,dtype=np.uint8)

                predict_arr = predict[idx_d].squeeze(0).cpu().numpy()*255
                predict_arr = np.array(predict_arr,dtype=np.uint8)

                cv2.imwrite(os.path.join(args.save_model_path,str(k_fold),"Mask_Single/{}_{}.png".format(idx_val,idx_d)),mask_arr)
                cv2.imwrite(os.path.join(args.save_model_path,str(k_fold),"Preds_Single/{}_{}.png".format(idx_val,idx_d)),predict_arr)


            counter += batch_size
            if counter <= slice_num:  # cube拼接
                cur_predict_cube.append(predict)
                cur_label_cube.append(label)
                if counter == slice_num:  # slice_num整除batch_size
                    end_flag = True
                    counter = 0  # counter清0，开始下一个cube计数
            else:  # slice_num不能整除batch_size
                last = batch_size - (counter - slice_num)  # 当前batch size中有last张属于当前处理的cube
                last_p = predict[0:last]  # 属于当前处理的cube的预测和标签
                last_l = label[0:last]
                first_p = predict[last:]  # 属于下一个cube的预测和标签
                first_l = label[last:]
                cur_predict_cube.append(last_p)  # 当前处理的cube拼接
                cur_label_cube.append(last_l)
                end_flag = True
                counter = counter - slice_num  # counter累计到下一个cube的值

            if end_flag:  # 拼接完成，end_flag为True
                end_flag = False
                label_cube = torch.cat(cur_label_cube, dim=0)
                predict_cube = torch.cat(cur_predict_cube, dim=0)  # 在0维拼接，列表转为slice_num*h*w的tensor

                cur_predict_cube = []  # 当前处理的cube列表清空
                cur_label_cube = []
                if counter != 0:  # 处理累计到下一个cube的slice
                    cur_predict_cube.append(first_p)
                    cur_label_cube.append(first_l)

                assert len(args.cuda.split(',')) * predict_cube.size()[0] == slice_num
                Dice, true_label, Acc = u.eval_multi_seg_3D_Single(predict_cube, label_cube,args.num_classes)  # 返回Dice列表, True_label列表中包含2个类别的像素数量，acc为标量值
                PCC = u.compute_PCC(predict_cube, label_cube)
                PC, SE, Jaccard, Pre = u.compute_score_Singl(predict_cube, label_cube,n_class=args.num_classes)  #注意修改

                class_id=0
                total_Dice0[class_id].append(Dice[class_id])
                total_SE.append(SE)
                total_PC.append(PC)
                total_JS.append(Jaccard)
                total_Pre.append(Pre)
                #total_F1[class_id].append(F1[class_id])
                total_PCC.append(PCC)# 如果该类别存在，total_Dice中对应的类别子列表加入该cube的该类计算结果值
                total_Acc.append(Acc)

                len0 = len(total_Dice0[0]) if len(total_Dice0[0]) != 0 else 1
                dice = sum(total_Dice0[0]) / len0
                se0 = sum(total_SE) / len(total_SE)
                pc0 = sum(total_PC) / len(total_PC)
                pre0 = sum(total_Pre) / len(total_Pre)
                js0 = sum(total_JS) / len(total_JS)
                pcc0 = sum(total_PCC) / len(total_PCC)
                acc = sum(total_Acc) / len(total_Acc)
                tbar.set_description(
                    ' Dice: %.4f, Acc: %.4f, SE0:%.4f,  Pre0:%.4f, JS0: %.4f, PC0: %.4f' % (
                    dice, acc,se0,pre0,js0,pc0))
        print('Dice:', dice)
        print('Acc:', acc)
        with open('{}/fold_Singl_{}_dice.txt'.format(args.save_model_path, k_fold), 'w') as f:

            f.write('\n')
            f.write('Single_Dice:' + str(dice) + ',')
            f.write('Single_Acc:' + str(acc) + ',')
            f.write('Single_SE0:' + str(se0) + ',')
            f.write('Single_Pre0:' + str(pre0) + ',')
            f.write('Single_JS0:' + str(js0) + ',')
            f.write('Single_PC0:' + str(pc0) + ',')
            f.write('Single_PCC0:' + str(pcc0) + ',')
            f.write('\n')




def test(args, model, dataloader_val, k_fold):

    val(args, model, dataloader_val, k_fold=k_fold)  # 验证集结果



def main(args=None, k_fold=1):
    # create dataset and dataloader
    dataset_path = './dataset/oct'
    dataset_val = OCT_Fluid(dataset_path, scale=(args.crop_height, args.crop_width),k_fold_test=k_fold, mode='val')
    dataloader_val = DataLoader(
        dataset_val,
        # this has to be 1
        batch_size=args.batch_size,  # 只选择1块gpu，batchsize=1
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=False
    )

    # set gpu
    os.environ['CUDA_VISIBLE_DEVICES'] = args.cuda  # 指定gpu

    # bulid model
    model = net_builder(args.net_work, args.num_classes, args.pretrained)
    print('Model have been loaded!,you chose the ' + args.net_work + '!')
    if torch.cuda.is_available() and args.use_gpu:
        model = torch.nn.DataParallel(model).cuda()  # torch.nn.DataParallel是支持并行GPU使用的模型包装器，并将模型放到cuda上

    trained_model_path = os.path.join(args.save_model_path_trained,str(k_fold))

    model_for_test = glob.glob(trained_model_path+"/*.pth.tar")[0]
    checkpoint = torch.load(
        model_for_test)  # torch.load：使用pickle unpickle工具将pickle的对象文件反序列化为内存，包括参数、优化器、epoch等
    model.load_state_dict(checkpoint['state_dict'])  # torch.nn.Module.load_state_dict:使用反序列化状态字典加载model’s参数字典
    print('=============Done!=============')
    print("trained_model_path ============= {}".format(trained_model_path))


    test(args, model, dataloader_val, k_fold)



if __name__ == '__main__':

    args = DefaultConfig()  # 配置设置
    modes = args.mode

    if modes == 'train':
        for fold_Test in range(0, 4):
            main(args=args, k_fold=int(fold_Test + 1))
